# kicad-library
My personal KiCAD library
